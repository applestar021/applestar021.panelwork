import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, Star, Users, Award, Zap } from "lucide-react"
import Image from "next/image"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b-2 border-amber-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2 space-x-reverse">
            <Image
              src="/logo.jpg"
              alt="Apple Star 021 Logo"
              width={80}
              height={80}
              className="h-16 w-16 rounded-full"
            />
            <div className="flex flex-col">
              <h1 className="text-2xl md:text-3xl font-extrabold bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 bg-clip-text text-transparent tracking-wide">
                Apple STAR021
              </h1>
              <p className="text-sm text-amber-600 font-semibold tracking-wider uppercase">Digital Solutions</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-700 hover:text-amber-600 transition-colors">
              خانه
            </a>
            <a href="#about" className="text-gray-700 hover:text-amber-600 transition-colors">
              درباره ما
            </a>
            <a href="#services" className="text-gray-700 hover:text-amber-600 transition-colors">
              خدمات
            </a>
            <a href="#contact" className="text-gray-700 hover:text-amber-600 transition-colors">
              تماس
            </a>
          </nav>
          <Button className="bg-amber-500 hover:bg-amber-600">شروع کنید</Button>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="py-20 bg-gradient-to-br from-yellow-50 to-amber-100 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-10 left-10 w-32 h-32 bg-amber-300/20 rounded-full blur-xl"></div>
          <div className="absolute bottom-20 right-20 w-48 h-48 bg-yellow-300/20 rounded-full blur-xl"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-200/10 rounded-full blur-2xl"></div>
        </div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6" style={{ fontFamily: "Maktab, serif" }}>
              Apple Star خوش آمدید
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              ما بهترین راه‌حل‌های دیجیتال را برای کسب‌وکار شما ارائه می‌دهیم. با تکنولوژی‌های پیشرفته و تیم متخصص، موفقیت
              شما را تضمین می‌کنیم.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-lg px-8 py-3">
                مشاوره رایگان
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 py-3 bg-transparent">
                مشاهده نمونه کارها
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white relative">
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent"></div>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="space-y-2 p-6 rounded-lg border-2 border-amber-100 bg-gradient-to-b from-amber-50/50 to-white hover:border-amber-200 transition-all duration-300">
              <div className="flex justify-center">
                <div className="p-3 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full shadow-lg">
                  <Users className="h-12 w-12 text-white" />
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-900">500+</div>
              <div className="text-gray-600">مشتری راضی</div>
            </div>
            <div className="space-y-2 p-6 rounded-lg border-2 border-amber-100 bg-gradient-to-b from-amber-50/50 to-white hover:border-amber-200 transition-all duration-300">
              <div className="flex justify-center">
                <div className="p-3 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full shadow-lg">
                  <Award className="h-12 w-12 text-white" />
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-900">50+</div>
              <div className="text-gray-600">پروژه موفق</div>
            </div>
            <div className="space-y-2 p-6 rounded-lg border-2 border-amber-100 bg-gradient-to-b from-amber-50/50 to-white hover:border-amber-200 transition-all duration-300">
              <div className="flex justify-center">
                <div className="p-3 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full shadow-lg">
                  <Star className="h-12 w-12 text-white" />
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-900">5.0</div>
              <div className="text-gray-600">امتیاز مشتریان</div>
            </div>
            <div className="space-y-2 p-6 rounded-lg border-2 border-amber-100 bg-gradient-to-b from-amber-50/50 to-white hover:border-amber-200 transition-all duration-300">
              <div className="flex justify-center">
                <div className="p-3 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full shadow-lg">
                  <Zap className="h-12 w-12 text-white" />
                </div>
              </div>
              <div className="text-3xl font-bold text-gray-900">24/7</div>
              <div className="text-gray-600">پشتیبانی</div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent"></div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50 relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-200/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-yellow-200/10 rounded-full blur-2xl"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-8 h-8 border-l-4 border-t-4 border-amber-400"></div>
              <div className="absolute -bottom-4 -right-4 w-8 h-8 border-r-4 border-b-4 border-amber-400"></div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6 relative">
                درباره ما
                <div className="absolute -bottom-2 left-0 w-16 h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-full"></div>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                ما یک تیم متخصص و با تجربه هستیم که در زمینه طراحی و توسعه وب‌سایت، اپلیکیشن موبایل و راه‌حل‌های دیجیتال
                فعالیت می‌کنیم.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                هدف ما کمک به کسب‌وکارها برای رسیدن به اهداف خود از طریق استفاده از بهترین تکنولوژی‌ها و روش‌های نوین است.
              </p>
              <Button size="lg" className="bg-amber-500 hover:bg-amber-600">
                بیشتر بدانید
              </Button>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="About Us"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 relative">
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-amber-200/20 rounded-full blur-2xl"></div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4 relative z-10">
              خدمات ما
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-full"></div>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              مجموعه کاملی از خدمات دیجیتال برای رشد و موفقیت کسب‌وکار شما
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-amber-200 hover:bg-gradient-to-b hover:from-amber-50/30 hover:to-white group">
              <CardHeader className="relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <CardTitle className="text-xl group-hover:text-amber-700 transition-colors">طراحی وب‌سایت</CardTitle>
                <CardDescription>طراحی وب‌سایت‌های مدرن و ریسپانسیو با بهترین تجربه کاربری</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">وب‌سایت‌های سریع، زیبا و بهینه شده برای موتورهای جستجو</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-amber-200 hover:bg-gradient-to-b hover:from-amber-50/30 hover:to-white group">
              <CardHeader className="relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <CardTitle className="text-xl group-hover:text-amber-700 transition-colors">اپلیکیشن موبایل</CardTitle>
                <CardDescription>توسعه اپلیکیشن‌های موبایل برای iOS و Android</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">اپلیکیشن‌های کاربردی و جذاب با عملکرد بالا</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-amber-200 hover:bg-gradient-to-b hover:from-amber-50/30 hover:to-white group">
              <CardHeader className="relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <CardTitle className="text-xl group-hover:text-amber-700 transition-colors">
                  بازاریابی دیجیتال
                </CardTitle>
                <CardDescription>استراتژی‌های بازاریابی آنلاین برای افزایش فروش</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">SEO، تبلیغات آنلاین و مدیریت شبکه‌های اجتماعی</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-amber-200 hover:bg-gradient-to-b hover:from-amber-50/30 hover:to-white group">
              <CardHeader className="relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <CardTitle className="text-xl group-hover:text-amber-700 transition-colors">مشاوره فنی</CardTitle>
                <CardDescription>مشاوره تخصصی در زمینه تکنولوژی و دیجیتال</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">راهنمایی و مشاوره برای انتخاب بهترین راه‌حل‌ها</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-amber-200 hover:bg-gradient-to-b hover:from-amber-50/30 hover:to-white group">
              <CardHeader className="relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <CardTitle className="text-xl group-hover:text-amber-700 transition-colors">پشتیبانی فنی</CardTitle>
                <CardDescription>پشتیبانی 24/7 برای تمام پروژه‌ها و خدمات</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">تیم پشتیبانی متخصص آماده کمک به شما</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-2 border-transparent hover:border-amber-200 hover:bg-gradient-to-b hover:from-amber-50/30 hover:to-white group">
              <CardHeader className="relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <CardTitle className="text-xl group-hover:text-amber-700 transition-colors">هاستینگ و دامنه</CardTitle>
                <CardDescription>خدمات هاستینگ پرسرعت و ثبت دامنه</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">سرورهای قدرتمند با آپتایم 99.9 درصد</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50 relative overflow-hidden">
        <div className="absolute top-10 right-10 w-40 h-40 bg-amber-300/10 rounded-full blur-2xl"></div>
        <div className="absolute bottom-10 left-10 w-56 h-56 bg-yellow-300/10 rounded-full blur-3xl"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16 relative">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              تماس با ما
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-gradient-to-r from-amber-400 to-amber-600 rounded-full"></div>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              آماده همکاری با شما هستیم. همین حالا با ما در تماس باشید
            </p>
          </div>
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <Card className="border-2 border-amber-100 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <CardTitle>فرم تماس</CardTitle>
                  <CardDescription>پیام خود را برای ما ارسال کنید</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input placeholder="نام" />
                    <Input placeholder="نام خانوادگی" />
                  </div>
                  <Input placeholder="ایمیل" type="email" />
                  <Input placeholder="شماره تماس" />
                  <Textarea placeholder="پیام شما" rows={4} />
                  <Button className="w-full bg-amber-500 hover:bg-amber-600">ارسال پیام</Button>
                </CardContent>
              </Card>
            </div>
            <div className="space-y-8">
              <div className="flex items-start space-x-4 space-x-reverse p-4 rounded-lg border border-amber-100 bg-gradient-to-r from-amber-50/50 to-white hover:from-amber-50 hover:to-amber-50/50 transition-all duration-300">
                <div className="bg-gradient-to-br from-amber-400 to-amber-600 p-3 rounded-lg shadow-md">
                  <Phone className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">تماس تلفنی</h3>
                  <p className="text-gray-600">09109999658</p>
                  <p className="text-gray-600">09109090752</p>
                  <p className="text-gray-600">09109090753</p>
                </div>
              </div>
              <div className="flex items-start space-x-4 space-x-reverse p-4 rounded-lg border border-amber-100 bg-gradient-to-r from-amber-50/50 to-white hover:from-amber-50 hover:to-amber-50/50 transition-all duration-300">
                <div className="bg-gradient-to-br from-amber-400 to-amber-600 p-3 rounded-lg shadow-md">
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">ایمیل</h3>
                  <p className="text-gray-600">mahanjafari869@gmail.com</p>
                  <p className="text-amber-600 text-sm">پاسخگویی سریع در تمام ساعات</p>
                </div>
              </div>
              <div className="flex items-start space-x-4 space-x-reverse p-4 rounded-lg border border-amber-100 bg-gradient-to-r from-amber-50/50 to-white hover:from-amber-50 hover:to-amber-50/50 transition-all duration-300">
                <div className="bg-gradient-to-br from-amber-400 to-amber-600 p-3 rounded-lg shadow-md">
                  <Mail className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">اینستاگرام</h3>
                  <p className="text-gray-600">@Apple.Star021</p>
                  <p className="text-amber-600 text-sm">instagram.com/Apple.Star021</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-400 to-transparent"></div>
        <div className="absolute top-4 right-4 w-32 h-32 bg-amber-400/5 rounded-full blur-xl"></div>
        <div className="absolute bottom-4 left-4 w-24 h-24 bg-yellow-400/5 rounded-full blur-lg"></div>
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <Image
                src="/logo.jpg"
                alt="Apple Star 021 Logo"
                width={80}
                height={80}
                className="h-16 w-16 rounded-full"
              />
              <p className="text-gray-400">Apple Star 021 - بهترین راه‌حل‌های دیجیتال و خدمات اپل</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">خدمات</h3>
              <ul className="space-y-2 text-gray-400">
                <li>طراحی وب‌سایت</li>
                <li>اپلیکیشن موبایل</li>
                <li>بازاریابی دیجیتال</li>
                <li>مشاوره فنی</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">شرکت</h3>
              <ul className="space-y-2 text-gray-400">
                <li>درباره ما</li>
                <li>تیم ما</li>
                <li>نمونه کارها</li>
                <li>اخبار</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">تماس</h3>
              <ul className="space-y-2 text-gray-400">
                <li>09109999658</li>
                <li>mahanjafari869@gmail.com</li>
                <li>@Apple.Star021</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 تمام حقوق محفوظ است.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
